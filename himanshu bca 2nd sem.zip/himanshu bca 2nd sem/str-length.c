#include <stdio.h>
#include<string.h>
#include<conio.h>

void main() {
    int i ,c=0;
    char str[200];
    gets(str);
    // with strlen the length of string
    printf("%d\n",strlen(str));

    // without strlen the length of string
    while (str[c] != '\0') {
        c++;
    }
    printf("%d",c);
   getch();

}
    

