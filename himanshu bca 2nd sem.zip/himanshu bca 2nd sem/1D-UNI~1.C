#include <stdio.h>
#include<conio.h>

void main() {
    int i,j,n,c;
    int arr[100];
    printf("Enter no. of element in arr: ");
    scanf("%d", &n);
    // Taking input
    for ( i = 0; i < n; i++) {
	printf("Enter %d element: ", i);
	scanf("%d", &arr[i]);
    }

    for ( i = 0; i < n; i++) {
      c=0;
      for ( j = 0;j<n ;j++){

       if (arr[j]==arr[i]){
	  c++;
	  }
      }

      if (c==1){
	printf("%d\n",arr[i]);
      }

    }
   getch();

}