#include <stdio.h>
#include<string.h>
#include<conio.h>
void main() {
    int i ,c=0;
    char s1[100];
    printf("enter srting : ");
    gets(s1);
     clrscr();
     i=0;
     printf("upper case");
    while(s1[i]!='\0'){
       printf("%d",toupper(s1[i]));
       
        i++;
    }
    i=0;
    printf("lower case");
   while(s1[i]!='\0'){
      printf("%d",tolower(s1[i]));
      
       i++;
   }
   getch();
}

