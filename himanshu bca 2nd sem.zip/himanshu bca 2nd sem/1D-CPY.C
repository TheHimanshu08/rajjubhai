#include <stdio.h>
#include<conio.h>

void main() {
    int n,i;
    int arr[100],cpy[100];
    printf("Enter no. of element in arr: ");
    scanf("%d", &n);
    // Taking input
    for ( i = 0; i < n; i++) {
	printf("Enter %d element: ", i);
	scanf("%d", &arr[i]);
    }
    printf("the copied array : ");
    for ( i = 0; i < n; i++) {
       cpy[i]=arr[i];

       printf("%d,",cpy[i]);
    }
    getch();

}
