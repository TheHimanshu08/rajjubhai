#include <stdio.h>
#include<conio.h>

void main() {
    int n,i,j,e=0,o=0,c,d;

    int a[100],E[100],O[100];
    printf("Enter no. of element in arr: ");
    scanf("%d", &n);
    // Taking input
    for ( i = 0; i < n; i++) {
        printf("Enter %d element: ", i);
        scanf("%d", &a[i]);
    }


    printf("The even no. are : \n");
    for ( i = 0; i < n; i++) {
        if (a[i]%2==0){
            printf("%d\n",a[i]);
        }}
    printf("The odd no. are : \n");
    for ( i = 0; i < n; i++) {
        if (a[i]%2!=0){
            printf("%d\n",a[i]);
        }}


    for ( i = 0; i < n; i++) {
        if (a[i]%2==0){
            e=e+a[i];  }
        else {
            o=o+a[i]; }      
    }
    printf("the sum of even no. is %d\n",e);
    printf("the sum of odd no. is %d\n",o);

    getch();
 
}
    