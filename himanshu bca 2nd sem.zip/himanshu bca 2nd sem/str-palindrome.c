#include <stdio.h>
#include<string.h>
#include<conio.h>
void main() {
    int i ;
    char s1[100],s2[100];
    printf("enter srting : ");
    gets(s1);
     clrscr();

  strcpy(s2, strrev(s1));

      strrev(s2);
    if (strcmp(s2,s1) ==0){
        printf("the string is palindrome");
    }
    else{
        printf("this is not palindrome");
    }
    getch();
   }