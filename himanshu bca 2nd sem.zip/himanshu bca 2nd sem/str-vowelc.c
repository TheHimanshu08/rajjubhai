#include <stdio.h>
#include<string.h>
#include<conio.h>
void main() {
    int i ,c=0;
    char s1[100];
    printf("enter srting : ");
    gets(s1);
    //  clrscr();
     i=0;
    while(s1[i]!='\0'){
        if (s1[i]=='a'||s1[i]=='e'||s1[i]=='i'||s1[i]=='o'||s1[i]=='i'||s1[i]=='A'||s1[i]=='I'||s1[i]=='O'||s1[i]=='E'||s1[i]=='U'){
            c++;
        }
        i++;
    }
    printf("%d",c);
    getch();

}


  
