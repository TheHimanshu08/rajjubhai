#include <stdio.h>
#include<string.h>
#include<conio.h>
void main() {
    int i ;
    char s1[100],s2[100];
    printf("enter srting : ");
    gets(s1);
     clrscr();

  strcpy(s2, strrev(s1));
    puts(s2);
   getch();

}