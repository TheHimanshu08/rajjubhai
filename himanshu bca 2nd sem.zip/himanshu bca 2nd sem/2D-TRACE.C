#include <stdio.h>
#include<conio.h>

void main() {
    int i,j,s=0;


    int A[3][3],B[3][3];
    // matrix A input
    for ( i = 0; i < 3; i++) {
       for ( j = 0; j < 3; j++) {
        printf("%d,%d element :- ",i,j);
       scanf("%d",&A[i][j]);
       }   
    }
    // print matrix A
    printf("The matrix A is \n");
    for ( i = 0; i < 3; i++) {
        for ( j = 0; j < 3; j++) {
        printf("%d ",A[i][j]); 
        }
        printf("\n");
     }

    //   main logic is now 
    printf("The matrix C is \n");
     s=0;
    for ( i = 0; i < 3; i++) {
        for ( j = 0; j < 3; j++) {
        if (i==j){
            s =A[i][j]+s;
            
        } } }
    printf("the trace of matrix is %d",s);
   getch();
    
    }