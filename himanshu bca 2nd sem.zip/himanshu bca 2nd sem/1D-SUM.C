#include <stdio.h>
#include<conio.h>

void main() {
    int i, n,s=0;
    int arr[100];
    printf("Enter no. of element in arr: ");
    scanf("%d", &n);
    // Taking input
    for ( i = 0; i < n; i++) {
        printf("Enter %d element: ", i);
        scanf("%d", &arr[i]);
    }
    
    for(i=0;i<n;i++){
        s=s+arr[i];
    
    }
    printf("%d",s);
   getch();

}