#include <stdio.h>
#include<string.h>
#include<conio.h>
void main() {
    int i ;
    char s1[100],s2[100],s3[200];
    printf("enter 1st srting : ");
    gets(s1);
    printf("enter 1st srting : ");
    gets(s2);
    //  clrscr();

  strcpy(s3, strcat(s1,s2));
    puts(s3);
   getch();

}