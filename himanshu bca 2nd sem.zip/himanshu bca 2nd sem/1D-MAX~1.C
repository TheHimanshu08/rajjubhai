#include <stdio.h>
#include<conio.h>

void main() {
    int n,i,j,min,max;
    int a[100];
    printf("Enter no. of element in arr: ");
    scanf("%d", &n);
    
    // Taking input
    for ( i = 0; i < n; i++) {
        printf("Enter %d element: ", i);
        scanf("%d", &a[i]);
    }
    max=a[0];
    min=a[0];
    for ( i = 0; i < n; i++) {
        if (min>a[i]){
            min=a[i];
        }
        if (max<a[i]){
            max=a[i];
        }  }

    printf("the max in %d\n the min is %d",max,min);
    getch();

}
    