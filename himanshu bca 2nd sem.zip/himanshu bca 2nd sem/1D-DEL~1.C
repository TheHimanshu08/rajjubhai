#include <stdio.h>
#include<conio.h>

void main() {
    int n,i,k;
    int a[100];
    printf("Enter no. of element in arr: ");
    scanf("%d", &n);
    // Taking input
    for ( i = 0; i < n; i++) {
        printf("Enter %d element: ", i);
        scanf("%d", &a[i]);
    }
    printf("give the position no.to delete the element :- ");
    scanf("%d",&k);

    for(i=0;i<n;i++){
        if (i>=k){
            a[i]=a[i+1];
        }
        
    }
    
    for(i=0;i<n-1;i++){
        printf(" %d element: %d\n",i,a[i]);
    }
   getch();

}

    