#include <stdio.h>
#include<conio.h>

void main() {
    int i,j, n,c, a[100];
    printf("Enter no. of element in arr: ");
    scanf("%d", &n);
    // Taking input
    for ( i = 0; i < n; i++) {
	printf("Enter %d element: ", i);
	scanf("%d", &a[i]);
    }

    for ( i = 0; i < n; i++) {
	c=0;
	for ( j = 0;j<n ;j++){

	 if (a[j]==a[i]){
	    c++;
	    }
	}

	printf("%d freq of elemnt in %d\n",a[i],c);
    }
    getch();

}