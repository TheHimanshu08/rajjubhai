#include <stdio.h>
#include<conio.h>

void main() {
    int i,j,k,m;
    int A[3][3],B[3][3];
    // matrix A input
    for ( i = 0; i < 3; i++) {
       for ( j = 0; j < 3; j++) {
        printf("%d,%d element :- ",i,j);
       scanf("%d",&A[i][j]);
       }   
    }
    // print matrix A
    printf("The matrix A is \n");
    for ( i = 0; i < 3; i++) {
        for ( j = 0; j < 3; j++) {
        printf("%d ",A[i][j]); 
        }
        printf("\n");
     }

    //   main logic is now 
    printf("The matrix C is \n");

    for ( i = 0; i < 3; i++) {
        for ( j = 0; j < 3; j++) {
        B[i][j]=A[j][i];
        printf("%d ",B[i][j]); 
        }
        printf("\n");
     }
     getch();
   
   }