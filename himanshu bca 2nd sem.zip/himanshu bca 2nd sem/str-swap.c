#include <stdio.h>
#include<string.h>
#include<conio.h>
void main() {
    int i ;
    char s1[100],s2[100],s3[100];
    printf("enter 1st srting : ");
    gets(s1);
    printf("enter 2nd srting : ");
    gets(s2);
    //  clrscr();
    // swap using 3rd one

    strcpy(s3, s1);
    strcpy(s1, s2);
    strcpy(s2, s3);
    printf("now the 1st srting : ");
    puts(s1);
    printf("now the 2nd srting : ");
    puts(s2);

   getch();


}